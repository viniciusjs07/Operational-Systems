#include <math.h>

 int main() {
	 int count = 524436200;

     while(count-- !=0) {
         pow(1.2, 2.3);
     }
     return 0;
 }
